import os
import asyncio
import json
import base64
from datetime import datetime

import requests
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardButton, InlineKeyboardMarkup
)
from nebula import Nebula, ContextFilter
from dotenv import load_dotenv

from pymongo import MongoClient
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from web3 import Web3, Account

# ─── Load environment variables ─────────────────────────────────────────────────
load_dotenv()
TELEGRAM_TOKEN      = os.getenv("TELEGRAM_TOKEN")
THIRDWEB_SECRET_KEY = os.getenv("THIRDWEB_SECRET_KEY")
ETHERSCAN_API_KEY   = os.getenv("ETHERSCAN_API_KEY", "")
MONGODB_URI         = os.getenv("MONGODB_URI")
MONGODB_DBNAME      = os.getenv("MONGODB_DBNAME", "telegram_bot_db")
AES_SECRET_KEY_B64  = os.getenv("AES_SECRET_KEY")
INFURA_ETH_URL      = os.getenv("INFURA_ETH_URL", "")

# Decode base64 AES key (must be 32 bytes)
if not AES_SECRET_KEY_B64:
    raise RuntimeError("AES_SECRET_KEY not set in .env")
padded_key = AES_SECRET_KEY_B64
if len(padded_key) % 4:
    padded_key += "=" * (4 - (len(padded_key) % 4))
try:
    AES_SECRET_KEY = base64.b64decode(padded_key)
    if len(AES_SECRET_KEY) != 32:
        raise RuntimeError("AES_SECRET_KEY must decode to exactly 32 bytes")
except Exception as e:
    raise RuntimeError(f"Invalid AES_SECRET_KEY: {e}")

# ─── Initialize Telegram bot and dispatcher ────────────────────────────────────
bot = Bot(token=TELEGRAM_TOKEN)
dp  = Dispatcher()

# ─── Initialize Nebula client (Python SDK) ─────────────────────────────────────
nebula = Nebula(
    base_url="https://nebula-api.thirdweb.com",
    secret_key=THIRDWEB_SECRET_KEY
)

# ─── Initialize MongoDB client ─────────────────────────────────────────────────
mongo_client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=5000)
db           = mongo_client[MONGODB_DBNAME]
users_col    = db["users"]

# ─── AES‐GCM helpers to encrypt/decrypt private keys ────────────────────────────
aesgcm = AESGCM(AES_SECRET_KEY)

def encrypt_privkey(priv_hex: str) -> str:
    nonce = os.urandom(12)
    ct    = aesgcm.encrypt(nonce, bytes.fromhex(priv_hex), None)
    return base64.b64encode(nonce + ct).decode()

def decrypt_privkey(b64_cipher: str) -> str:
    data  = base64.b64decode(b64_cipher)
    nonce = data[:12]
    ct    = data[12:]
    pt    = aesgcm.decrypt(nonce, ct, None)
    return pt.hex()

# ─── Supported chain name → chain ID mapping ───────────────────────────────────
CHAIN_NAME_TO_ID = {
    "ethereum":      "1",
    "goerli":        "5",
    "sepolia":       "11155111",
    "polygon":       "137",
    "mumbai":        "80001",
    "bsc":           "56",
    "bnb":           "56",   # alias
    "bsc-testnet":   "97",
    "avalanche":     "43114",
    "avax":          "43114", # alias
    "fuji":          "43113",
    "fantom":        "250",
    "opera":         "250",  # alias
    "fantom-testnet":"4002",
    "arbitrum":      "42161",
    "arbitrum-goerli":"421613",
    "optimism":      "10",
    "optimism-goerli":"420",
}

# In‐memory per‐user state:
#   user_state[chat_id] = {
#     "chain_id": str,
#     "awaiting_import": bool,
#     "awaiting_contract": bool,
#     "selected_token_addr": str,
#     "selected_chain_id": str,
#     "wallet_count": int,
#   }
user_state: dict[int, dict[str, any]] = {}

# ─── Main Menu Keyboard (persistent) ───────────────────────────────────────────
MAIN_MENU = ReplyKeyboardMarkup(
    keyboard=[
        [ KeyboardButton(text="My Wallets"), KeyboardButton(text="Import Wallet") ],
        [ KeyboardButton(text="Select Chain"), KeyboardButton(text="Clear Chain") ]
    ],
    resize_keyboard=True
)

# ─── Helper: Build a ReplyKeyboardMarkup of chain buttons ──────────────────────
def build_chain_keyboard():
    buttons = [ KeyboardButton(text=name.title()) for name in CHAIN_NAME_TO_ID.keys() ]
    rows    = [ buttons[i : i + 3] for i in range(0, len(buttons), 3) ]
    rows.append([ KeyboardButton(text="Back to Menu") ])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)

CHAIN_KEYBOARD = build_chain_keyboard()

# ─── Helper: Normalize chain input ────────────────────────────────────────────
def resolve_chain_id(chain_input: str) -> str | None:
    key = chain_input.strip().lower()
    if key in CHAIN_NAME_TO_ID:
        return CHAIN_NAME_TO_ID[key]
    if key.isdigit():
        return key
    return None

# ─── Generate a fresh Web3 wallet ─────────────────────────────────────────────
def generate_wallet() -> dict:
    acct = Account.create()
    return {
        "address": acct.address.lower(),
        "private_key": acct.key.hex()[2:]
    }

# ─── Explicit /start handler ───────────────────────────────────────────────────
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    """
    If the user sends /start, we either register them (if new)
    or re‐send the welcome text (if they already exist).
    """
    user_id = message.from_user.id
    user = users_col.find_one({"chat_id": user_id})

    if not user:
        # New user: create 8 wallets and send the welcome packet
        await register_new_user(message)
    else:
        # Existing user: send "welcome back" summary
        welcome_back = (
            "👋 *Welcome back to MCPAIRIS_BOT!*\n\n"
            "You already have wallets on file, so you can immediately:\n"
            "▶️ Tap *My Wallets* to see your addresses.\n"
            "▶️ Tap *Import Wallet* to add a private key (if you need more wallets).\n"
            "▶️ Tap *Select Chain* to choose a network and analyze a token.\n"
            "▶️ Tap *Clear Chain* to reset your network choice.\n\n"
            "Whenever you're ready, just use the buttons below."
        )
        await message.reply(welcome_back, parse_mode="Markdown", reply_markup=MAIN_MENU)


# ─── Unified "any message" handler ─────────────────────────────────────────────
@dp.message()
async def on_any_message(message: types.Message):
    """
    We look at the exact text of each button (or free text),
    decide which step of the flow the user is in, and respond accordingly.
    """
    text    = message.text.strip()
    lower   = text.lower()
    user_id = message.from_user.id

    # 1) If user not in the database, treat ANY incoming message as "/start"
    user = users_col.find_one({"chat_id": user_id})
    if not user:
        await register_new_user(message)
        return

    # 2) If user is in "awaiting_import" state, the text is a private key
    state = user_state.get(user_id, {})
    if state.get("awaiting_import", False):
        await handle_import_key(user_id, message, text)
        return

    # 3) If user is "awaiting_contract" (they chose a chain),
    #    the next text is the contract address to analyze
    if state.get("awaiting_contract", False):
        chain_id = state.get("chain_id")
        if lower.startswith("0x") and len(lower) >= 10:
            # record which token/chain they're analyzing
            user_state[user_id]["selected_token_addr"] = lower
            user_state[user_id]["selected_chain_id"]   = chain_id
            # Clear the awaiting_contract flag
            user_state[user_id]["awaiting_contract"] = False
            # Call fetch_and_reply_token_info in background
            asyncio.create_task(fetch_and_reply_token_info(message, chain_id, lower))
        else:
            await message.reply(
                "❗️ Please send a valid contract address (must start with 0x…).",
                reply_markup=MAIN_MENU
            )
        return

    # 4) Interpret the Main Menu button taps:
    if text == "My Wallets":
        await show_wallets(user_id, message)
        return

    if text == "Import Wallet":
        user_state.setdefault(user_id, {})["awaiting_import"] = True
        await message.reply(
            "🔐 Please send your *private key* (hex, with or without `0x`).\n"
            "I will encrypt it and store it securely (up to 8 wallets).",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    if text == "Select Chain":
        await message.reply("🌐 Select a network:", reply_markup=CHAIN_KEYBOARD)
        return

    if text == "Clear Chain":
        user_state.setdefault(user_id, {}).pop("chain_id", None)
        user_state[user_id].pop("selected_token_addr", None)
        await message.reply("🔄 Chain selection cleared.", reply_markup=MAIN_MENU)
        return

    if text == "Back to Menu":
        await message.reply("Returning to main menu…", reply_markup=MAIN_MENU)
        return

    if text == "Latest Tokens":
        # Trigger the /latesttokens flow asynchronously
        asyncio.create_task(cmd_latesttokens(message))
        return

    # 5) If text matches a chain name, store it & ask for contract address
    if lower in CHAIN_NAME_TO_ID:
        chain_id = CHAIN_NAME_TO_ID[lower]
        user_state.setdefault(user_id, {})["chain_id"]         = chain_id
        user_state[user_id]["awaiting_contract"] = True
        await message.reply(
            f"✅ Network set to *{lower.title()}* (chain ID: {chain_id}).\n\n"
            "Now send me the *contract address* (starting with 0x…) to analyze.",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    # 6) Unrecognized text (and not in an "awaiting" state)
    await message.reply(
        "❗️ I didn't understand that. Please use one of the buttons below:\n"
        "- *My Wallets* to view your addresses\n"
        "- *Import Wallet* to add a private key\n"
        "- *Select Chain* to pick a network & then send me a contract\n"
        "- *Clear Chain* to reset your network choice\n",
        parse_mode="Markdown",
        reply_markup=MAIN_MENU
    )


async def register_new_user(message: types.Message):
    """
    Called when the user is not yet in the database.
    We create 8 new wallets, encrypt their private keys, store them,
    and send a welcome packet with description + Main Menu.
    """
    user_id = message.from_user.id
    wallets = []
    for _ in range(8):
        w = generate_wallet()
        wallets.append({
            "address": w["address"],
            "priv_enc": encrypt_privkey(w["private_key"])
        })
    new_doc = {
        "chat_id":    user_id,
        "wallets":    wallets,
        "imported":   [],
        "created_at": datetime.utcnow()
    }
    users_col.insert_one(new_doc)
    user_state[user_id] = {}  # initialize empty state

    # --- Customized welcome message for MCPAIRIS_BOT ---
    welcome_text = (
        "🤖 *Welcome to MCPAIRIS_BOT!*\n\n"
        "$MCPAIR (MCPAIris) is a next-gen Web3 trading bot, designed to empower DeFi traders with AI-driven automation.\n\n"
        "By leveraging advanced artificial intelligence (AI) and Multi Context Protocols (MCPs), $MCPAIR enables users to auto-trade across multiple decentralized exchanges (DEXes) and launchpads, "
        "such as Uniswap, pump.fun, and letsbonk, on blockchains like Ethereum and Solana.\n\n"
        "The platform's flagship *AIris* system—combining AI with \"all-seeing vision\"—analyzes tokenomics, market sentiment, and on-chain data to identify high return-to-risk tokens, "
        "helping users maximize profits in the fast-paced DeFi market.\n\n"
        "*How to start:*\n"
        "▶️ Tap *My Wallets* to see your 8 freshly generated wallets (encrypted in our DB).\n"
        "▶️ Tap *Import Wallet* if you want to add your own private key (up to 8 total).\n"
        "▶️ Tap *Select Chain* to choose a network (e.g. Ethereum, Polygon, BSC).\n"
        "▶️ After selecting a chain, paste a contract address (0x…) to analyze that token.\n\n"
        "Thank you for using MCPAIRIS_BOT—let's trade smarter!"
    )

    # Send the welcome text with Markdown and show the Main Menu keyboard
    await message.reply(welcome_text, parse_mode="Markdown", reply_markup=MAIN_MENU)
    print(f"[INFO] New user {user_id} registered with 8 wallets.")


async def show_wallets(user_id: int, message: types.Message):
    """
    Shows all stored wallet addresses for this user.
    """
    user = users_col.find_one({"chat_id": user_id})
    if not user:
        await message.reply("❗️ You're not registered yet. Tap any button to start.")
        return

    all_wallets = user.get("wallets", []) + user.get("imported", [])
    if not all_wallets:
        text = "You have no wallets on file."
    else:
        text = "*Your wallets:* \n\n"
        for idx, w in enumerate(all_wallets, 1):
            text += f"{idx}. `{w['address']}`\n"
    await message.reply(text, parse_mode="Markdown", reply_markup=MAIN_MENU)


async def handle_import_key(user_id: int, message: types.Message, text: str):
    """
    After tapping "Import Wallet," the next text is expected to be a private key.
    We validate its format, encrypt it, and store it (max 8). If >8, we replace the oldest.
    """
    key_text = text.strip()
    raw_key  = key_text[2:] if key_text.startswith("0x") else key_text

    # 1) Validate raw_key length and hex characters
    if len(raw_key) != 64 or not all(c in "0123456789abcdefABCDEF" for c in raw_key):
        user_state[user_id]["awaiting_import"] = False
        await message.reply(
            "❗️ Invalid private key format. Must be exactly 64 hex chars (with or without `0x`).",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    # 2) Validate with web3.py
    try:
        acct = Account.from_key(bytes.fromhex(raw_key))
    except Exception:
        user_state[user_id]["awaiting_import"] = False
        await message.reply(
            "❗️ That private key could not be parsed. Try again or tap *Import Wallet* once more.",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    # 3) Fetch the user's document
    user = users_col.find_one({"chat_id": user_id})
    if not user:
        user_state[user_id]["awaiting_import"] = False
        await message.reply("❗️ You're not registered. Tap any button to start.", reply_markup=MAIN_MENU)
        return

    wallets  = user.get("wallets", [])
    imported = user.get("imported", [])

    # 4) Append or replace
    if len(wallets) + len(imported) < 8:
        imported.append({
            "address": acct.address.lower(),
            "priv_enc": encrypt_privkey(raw_key)
        })
    else:
        # Replace first-generated
        if wallets:
            wallets.pop(0)
        imported.append({
            "address": acct.address.lower(),
            "priv_enc": encrypt_privkey(raw_key)
        })

    users_col.update_one(
        {"chat_id": user_id},
        {"$set": {"wallets": wallets, "imported": imported}}
    )
    user_state[user_id]["awaiting_import"] = False

    await message.reply(
        f"✅ Imported wallet `{acct.address}`.\n"
        f"You now have {len(wallets) + len(imported)} / 8 wallets on file.\n"
        "Tap *My Wallets* to view them.",
        parse_mode="Markdown",
        reply_markup=MAIN_MENU
    )
    print(f"[INFO] User {user_id} imported wallet {acct.address}.")


async def fetch_and_reply_token_info(message: types.Message, chain_id: str, address: str):
    """
    1) Send "Processing…"
    2) Nebula: name, symbol, decimals, price_usd, market_cap_usd
    3) Nebula: total_supply, unique_holders → divide by 10**decimals
    4) Fallback to Etherscan for supply & holders if needed
    5) Show token overview with MAIN_MENU + a new "Select Wallet Count" inline menu
    """
    user_id     = message.from_user.id
    human_chain = next((n for n, cid in CHAIN_NAME_TO_ID.items() if cid == chain_id), chain_id)

    # Send a "processing" placeholder
    try:
        processing_msg = await message.reply(
            "⏳ Analyzing contract address…\n"
            "Please wait while I fetch the token information.",
            parse_mode="Markdown"
        )
    except Exception as e:
        print(f"[ERROR] Failed to send processing message: {e}")
        return

    # Nebula ContextFilter: limit to this chain + contract
    context = ContextFilter(
        chain_ids=[chain_id],
        contract_addresses=[address],
        wallet_addresses=None
    )

    # ─── Nebula Chat: Basic token info ────────────────────────────────────────────
    prompt = (
        "Return a JSON object with exactly these keys:\n"
        "  • name\n"
        "  • symbol\n"
        "  • decimals\n"
        "  • price_usd\n"
        "  • market_cap_usd\n"
        "  • contract_address\n"
        "  • chain_id\n"
        f"For the ERC-20 token at address {address} on chain ID {chain_id}. "
        "If any field is unavailable, set it to null. Output only the JSON."
    )

    # Wrap nebula.chat in asyncio.to_thread to avoid blocking the event loop
    try:
        resp = await asyncio.to_thread(lambda: nebula.chat(message=prompt, stream=False, context_filter=context))
        raw  = getattr(resp, "message", "") or ""
    except Exception as e:
        await processing_msg.delete()
        await message.reply(f"⚠️ Nebula error: `{e}`", parse_mode="Markdown", reply_markup=MAIN_MENU)
        return

    data = {}
    try:
        data = raw if isinstance(raw, dict) else json.loads(raw)
    except:
        data = {}

    name       = data.get("name")       or "N/A"
    symbol     = data.get("symbol")     or "N/A"
    decimals   = data.get("decimals")
    price      = data.get("price_usd")
    market_cap = data.get("market_cap_usd")

    returned_address = data.get("contract_address") or address
    returned_chain   = data.get("chain_id")         or chain_id

    decimals_str = str(decimals) if isinstance(decimals, (int, str)) else "N/A"
    price_str    = f"${float(price):,.8f}" if price not in (None, "", "null") else "N/A"
    mcap_str     = f"${float(market_cap):,.2f}" if market_cap not in (None, "", "null") else "N/A"

    # ─── Nebula Chat: total_supply & unique_holders ───────────────────────────────
    supply_str  = "N/A"
    holders_str = "N/A"
    try:
        supply_prompt = (
            "Return a JSON object with exactly these keys:\n"
            "  • total_supply\n"
            "  • unique_holders\n"
            f"For the ERC-20 token at address {address} on chain ID {chain_id}. "
            "If any field is unavailable, set it to null. Output only the JSON."
        )
        resp2 = await asyncio.to_thread(lambda: nebula.chat(message=supply_prompt, stream=False, context_filter=context))
        raw2 = getattr(resp2, "message", "") or ""
        obj2 = raw2 if isinstance(raw2, dict) else json.loads(raw2)
        ts  = obj2.get("total_supply")
        uh  = obj2.get("unique_holders")
        if ts not in (None, "", "null") and isinstance(decimals, (int, str)):
            raw_int      = int(ts)
            denom        = 10 ** int(decimals)
            human_supply = raw_int / denom
            supply_str   = f"{human_supply:,.0f}"
        if uh not in (None, "", "null"):
            holders_str = f"{int(uh):,}"
    except Exception:
        pass

    # ─── Fallback via Etherscan (Ethereum mainnet only) ─────────────────────────
    if (supply_str == "N/A" or holders_str == "N/A") \
       and chain_id == "1" and ETHERSCAN_API_KEY:
        # totalSupply
        try:
            url_supply = (
                f"https://api.etherscan.io/api"
                f"?module=stats&action=tokensupply&contractaddress={address}"
                f"&apikey={ETHERSCAN_API_KEY}"
            )
            r1 = requests.get(url_supply, timeout=10).json()
            raw_supply = r1.get("result", "")
            if raw_supply.isdigit() and isinstance(decimals, (int, str)):
                raw_int      = int(raw_supply)
                denom        = 10 ** int(decimals)
                human_supply = raw_int / denom
                supply_str   = f"{human_supply:,.0f}"
        except Exception:
            pass

        # tokenHolderCount
        try:
            url_holders = (
                f"https://api.etherscan.io/api"
                f"?module=stats&action=tokenholdercount&contractaddress={address}"
                f"&apikey={ETHERSCAN_API_KEY}"
            )
            r2 = requests.get(url_holders, timeout=10).json()
            raw_holders = r2.get("result", "")
            if raw_holders.isdigit():
                holders_str = f"{int(raw_holders):,}"
        except Exception:
            pass

    # Build the formatted token-overview text
    reply_text = (
        f"*🔍 Token Overview*\n\n"
        f"*Name:* `{name}`\n"
        f"*Symbol:* `{symbol}`\n"
        f"*Decimals:* `{decimals_str}`\n"
        f"*Price (USD):* {price_str}\n"
        f"*Market Cap (USD):* {mcap_str}\n"
        f"*Total Supply:* `{supply_str}`\n"
        f"*Holders Count:* `{holders_str}`\n\n"
        f"*Chain:* `{human_chain.title()}` (ID: {returned_chain})\n"
        f"*Address:* `{returned_address}`\n"
    )

    # Delete the "processing" message
    try:
        await processing_msg.delete()
    except Exception:
        pass

    # 1) Send back the token overview (with MAIN_MENU again)
    await message.reply(reply_text, parse_mode="Markdown", reply_markup=MAIN_MENU)

    # 2) Now send an inline menu: "How many wallets to use?"
    wallet_count_buttons: list[list[InlineKeyboardButton]] = []
    temp = []
    for i in range(1, 9):
        text_btn = f"Use {i} Wallet" + ("s" if i != 1 else "")
        callback = f"wallet_count|{returned_address}|{returned_chain}|{i}"
        temp.append(InlineKeyboardButton(text=text_btn, callback_data=callback))
        if len(temp) == 3:
            wallet_count_buttons.append(temp)
            temp = []
    if temp:
        wallet_count_buttons.append(temp)

    # Final "Cancel" row:
    wallet_count_buttons.append([
        InlineKeyboardButton(text="× Cancel", callback_data="cancel_to_menu")
    ])

    keyboard_wallet_count = InlineKeyboardMarkup(inline_keyboard=wallet_count_buttons)
    await message.reply("💰 Number of wallets to use:", reply_markup=keyboard_wallet_count)
    print(f"[INFO] Offered wallet-count selection to user {user_id}.")


# ─── Callback handler for "wallet_count" and related actions ──────────────────
@dp.callback_query()
async def handle_wallet_count_and_actions(query: types.CallbackQuery):
    data = query.data  # e.g. "wallet_count|0xAbC...|1|3" or "cancel_to_menu" or later action callbacks
    user_id = query.from_user.id

    # 1) Cancel: go back to MAIN_MENU
    if data == "cancel_to_menu":
        await query.answer()  # dismiss "loading…" spinner
        await query.message.reply("Cancelled. Returning to main menu.", reply_markup=MAIN_MENU)
        return

    # 2) If prefix is "wallet_count"
    if data.startswith("wallet_count|"):
        # Format: "wallet_count|<contract_address>|<chain_id>|<num_wallets>"
        parts = data.split("|")
        if len(parts) != 4:
            await query.answer("❗️ Invalid selection.", show_alert=True)
            return

        _, token_addr, chain_id, count_str = parts
        try:
            count = int(count_str)
        except ValueError:
            await query.answer("❗️ Invalid wallet count.", show_alert=True)
            return

        # Record in user_state:
        user_state.setdefault(user_id, {})["wallet_count"]         = count
        user_state[user_id]["selected_token_addr"] = token_addr
        user_state[user_id]["selected_chain_id"]  = chain_id

        await query.answer(f"Selected {count} wallet(s).")
        # Build the "Actions" menu (mirroring your screenshot)
        action_buttons: list[list[InlineKeyboardButton]] = []

        # ▸ Row 1: Wallet Change – 1    Buy GWEI +1
        action_buttons.append([
            InlineKeyboardButton(text="Wallet Change – 1", callback_data="wallet_change|1"),
            InlineKeyboardButton(text="Buy GWEI +1",        callback_data="buy_gwei|1")
        ])

        # ▸ Row 2: Buy 0.1 ETH    Buy 0.2 ETH    Buy 0.5 ETH
        action_buttons.append([
            InlineKeyboardButton(text="Buy 0.1 ETH", callback_data="buy_amount|0.1"),
            InlineKeyboardButton(text="Buy 0.2 ETH", callback_data="buy_amount|0.2"),
            InlineKeyboardButton(text="Buy 0.5 ETH", callback_data="buy_amount|0.5"),
        ])

        # ▸ Row 3: Buy 1 ETH    Buy 2 ETH    Buy 5 ETH
        action_buttons.append([
            InlineKeyboardButton(text="Buy 1 ETH", callback_data="buy_amount|1"),
            InlineKeyboardButton(text="Buy 2 ETH", callback_data="buy_amount|2"),
            InlineKeyboardButton(text="Buy 5 ETH", callback_data="buy_amount|5"),
        ])

        # ▸ Row 4: Buy X ETH
        action_buttons.append([
            InlineKeyboardButton(text="Buy X ETH", callback_data="buy_amount|X")
        ])

        # ▸ Row 5: Anti-Rug    Transfer on Blacklist
        action_buttons.append([
            InlineKeyboardButton(text="🔴 Anti‐Rug",            callback_data="anti_rug"),
            InlineKeyboardButton(text="🔴 Transfer on Blacklist", callback_data="transfer_blacklist"),
        ])

        # ▸ Row 6: Slippage: Unlimited    Limit Order
        action_buttons.append([
            InlineKeyboardButton(text="✨ Slippage: Unlimited", callback_data="slippage_unlimited"),
            InlineKeyboardButton(text="📈 Limit Order",         callback_data="limit_order"),
        ])

        # ▸ Row 7: Pre Approve    Manual Settings
        action_buttons.append([
            InlineKeyboardButton(text="✅ Pre Approve",     callback_data="pre_approve"),
            InlineKeyboardButton(text="⚙️ Manual Settings", callback_data="manual_settings"),
        ])

        # ▸ Row 8: ← Back    × Cancel
        action_buttons.append([
            InlineKeyboardButton(text="← Back",        callback_data="back_to_wallet_count"),
            InlineKeyboardButton(text="× Cancel",      callback_data="cancel_to_menu"),
        ])

        keyboard_actions = InlineKeyboardMarkup(inline_keyboard=action_buttons)
        await query.message.reply(
            f"🔔 Using *{count}* wallet(s) to trade. Now choose an action:",
            parse_mode="Markdown",
            reply_markup=keyboard_actions
        )
        return

    # 3) If prefix is "back_to_wallet_count", re-show the "How many wallets?" menu
    if data == "back_to_wallet_count":
        st = user_state.get(user_id, {})
        token_addr = st.get("selected_token_addr")
        chain_id   = st.get("selected_chain_id")
        if not token_addr or not chain_id:
            await query.answer("❗️ Session expired. Please analyze the contract again.", show_alert=True)
            await query.message.reply("Returning to main menu.", reply_markup=MAIN_MENU)
            return

        await query.answer("Going back…")
        wallet_count_buttons = []
        temp = []
        for i in range(1, 9):
            text_btn = f"Use {i} Wallet" + ("s" if i != 1 else "")
            callback = f"wallet_count|{token_addr}|{chain_id}|{i}"
            temp.append(InlineKeyboardButton(text=text_btn, callback_data=callback))
            if len(temp) == 3:
                wallet_count_buttons.append(temp)
                temp = []
        if temp:
            wallet_count_buttons.append(temp)
        wallet_count_buttons.append([
            InlineKeyboardButton(text="× Cancel", callback_data="cancel_to_menu")
        ])
        keyboard_wallet_count = InlineKeyboardMarkup(inline_keyboard=wallet_count_buttons)
        await query.message.reply("💰 Number of wallets to use:", reply_markup=keyboard_wallet_count)
        return

    # 4) All other action callbacks: read token_addr, chain_id, wallet_count from user_state
    st = user_state.get(user_id, {})
    token_addr = st.get("selected_token_addr")
    chain_id   = st.get("selected_chain_id")
    wallet_cnt = st.get("wallet_count", 1)

    if data.startswith("wallet_change|"):
        _, idx_str = data.split("|")
        idx = int(idx_str)
        await query.answer(f"Switched to wallet # {idx} (out of {wallet_cnt}).")
        await query.message.reply(
            f"✅ Now using wallet # {idx} for future trades on `{token_addr}`.",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    if data.startswith("buy_gwei|"):
        _, inc_str = data.split("|")
        await query.answer(f"GWEI bumped by {inc_str}.")
        await query.message.reply(
            f"🛒 Will increase gas price (GWEI) by {inc_str}, then trade `{token_addr}` on chain ID {chain_id} using {wallet_cnt} wallet(s).",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    if data.startswith("buy_amount|"):
        _, amount_str = data.split("|")
        await query.answer(f"Buying {amount_str} ETH…")
        await query.message.reply(
            f"💸 Buying *{amount_str} ETH* worth of `{token_addr}` on chain {chain_id} with {wallet_cnt} wallet(s).",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    if data == "anti_rug":
        await query.answer("Anti‐Rug check…")
        await query.message.reply(
            "🛑 Anti‐Rug logic triggered. (Stub.)",
            reply_markup=MAIN_MENU
        )
        return

    if data == "transfer_blacklist":
        await query.answer("Blacklist transfer…")
        await query.message.reply(
            "📛 Transfer‐on‐Blacklist check. (Stub.)",
            reply_markup=MAIN_MENU
        )
        return

    if data == "slippage_unlimited":
        await query.answer("Slippage set to Unlimited.")
        await query.message.reply(
            "⚙️ Slippage is now *Unlimited* for this trade.",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    if data == "limit_order":
        await query.answer("Limit Order chosen.")
        await query.message.reply(
            "📈 Limit Order selected. (Stub: Show limit‐order UI.)",
            reply_markup=MAIN_MENU
        )
        return

    if data == "pre_approve":
        await query.answer("Preapproval…")
        await query.message.reply(
            "✅ Token pre‐approved successfully. (Stub.)",
            reply_markup=MAIN_MENU
        )
        return

    if data == "manual_settings":
        await query.answer("Manual Settings…")
        await query.message.reply(
            "⚙️ Manual Settings panel. (Stub.)",
            reply_markup=MAIN_MENU
        )
        return

    # 5) Unknown callback_data
    await query.answer("❗️ Unknown action. Returning to menu.", show_alert=True)
    await query.message.reply("Main menu:", reply_markup=MAIN_MENU)


# ─── Command handler for "/latesttokens" ────────────────────────────────────────
@dp.message(Command("latesttokens"))
async def cmd_latesttokens(message: types.Message):
    """
    Fetch and display the 2 most recently deployed ERC20 tokens on Ethereum mainnet.
    Uses Nebula.chat with an appropriate prompt & ContextFilter.
    Runs Nebula calls in a background thread so the bot remains responsive.
    """
    user_id = message.from_user.id

    # 1) Inform user we're fetching
    try:
        processing = await message.reply(
            "⏳ Fetching the latest 2 ERC20 token launches on Ethereum mainnet...\n"
            "Please wait a moment.",
            parse_mode="Markdown"
        )
    except Exception as e:
        # If reply fails, exit early
        print(f"[ERROR] Failed to send processing message: {e}")
        return

    # 2) Construct a Nebula prompt that asks for exactly 2 tokens
    prompt = (
        "Return a JSON array under the key \"tokens\", where each entry has exactly these fields:\n"
        "  • name\n"
        "  • symbol\n"
        "  • address\n"
        "  • total_supply\n"
        "List the 2 most recently deployed ERC20 tokens on Ethereum mainnet. Output only valid JSON."
    )

    # 3) Limit to Ethereum mainnet (chain ID 1)
    context = ContextFilter(
        chain_ids=["1"],
        contract_addresses=None,
        wallet_addresses=None
    )

    # 4) Call Nebula.chat inside asyncio.to_thread to avoid blocking
    raw = ""
    try:
        resp = await asyncio.to_thread(lambda: nebula.chat(message=prompt, stream=False, context_filter=context))
        raw = getattr(resp, "message", "") or ""
    except Exception as e:
        await processing.delete()
        await message.reply(
            f"⚠️ Nebula error while fetching latest tokens: `{e}`",
            parse_mode="Markdown",
            reply_markup=MAIN_MENU
        )
        return

    # 5) Attempt to parse JSON
    tokens = []
    try:
        parsed = raw if isinstance(raw, dict) else json.loads(raw)
        if isinstance(parsed, dict):
            maybe_list = parsed.get("tokens", [])
            if isinstance(maybe_list, list):
                tokens = maybe_list
    except Exception:
        tokens = []

    # 6) Delete the "processing" message
    try:
        await processing.delete()
    except Exception:
        pass

    # 7) Format the reply with up to 2 tokens
    if not tokens:
        await message.reply(
            "No recent ERC20 tokens found or unexpected response format.",
            reply_markup=MAIN_MENU
        )
        return

    reply_lines = ["🆕 *Latest 2 ERC20 Token Launches on Ethereum:*", ""]
    for idx, tk in enumerate(tokens[:2], start=1):
        name = tk.get("name", "N/A")
        symbol = tk.get("symbol", "N/A")
        addr = tk.get("address", "")
        supply = tk.get("total_supply", "N/A")
        reply_lines.append(f"{idx}. *Name:* {name}")
        reply_lines.append(f"   *Symbol:* {symbol}")
        reply_lines.append(f"   *Address:* `{addr}`")
        reply_lines.append(f"   *Total Supply:* {supply}")
        reply_lines.append("")

    reply_text = "\n".join(reply_lines)
    # In case it's still unexpectedly long, truncate to the first 4000 characters
    if len(reply_text) > 4000:
        reply_text = reply_text[:4000] + "\n\n(...)"

    await message.reply(reply_text, parse_mode="Markdown", reply_markup=MAIN_MENU)


# ─── Example stub for Quick Trade on Ethereum mainnet ─────────────────────────
async def quick_trade(w3_chain_id: str, token_address: str, account: Account, amount_in_eth: float) -> str:
    """
    Example stub:
      - Connect to Infura via INFURA_ETH_URL
      - Perform a swapExactETHForTokens on UniswapV2
      - Return the transaction hash (hex)
    """
    if w3_chain_id != "1":
        raise Exception("QuickTrade only implemented for Ethereum mainnet in this stub.")

    if not INFURA_ETH_URL:
        raise Exception("INFURA_ETH_URL is not set in .env")

    w3 = Web3(Web3.HTTPProvider(INFURA_ETH_URL))
    if not w3.is_connected():
        raise Exception("Cannot connect to Ethereum node.")

    router_address  = Web3.to_checksum_address("0x7a250d5630B4cF539739d2C5dAcb4c659F2488D")  # UniswapV2
    with open("IUniswapV2Router02.json") as f:
        router_abi = json.load(f)
    router_contract = w3.eth.contract(address=router_address, abi=router_abi)

    eth_amount_wei = w3.to_wei(amount_in_eth, "ether")
    path = [
        w3.to_checksum_address(w3.eth.default_account),
        w3.to_checksum_address(token_address)
    ]
    deadline = int(datetime.utcnow().timestamp()) + 120  # 2 minutes from now

    nonce = w3.eth.get_transaction_count(account.address)
    txn = router_contract.functions.swapExactETHForTokens(
        0,         # amountOutMin = 0 (no slippage protection)
        path,
        account.address,
        deadline
    ).build_transaction({
        "from":     account.address,
        "value":    eth_amount_wei,
        "gas":      300_000,
        "gasPrice": w3.to_wei("50", "gwei"),
        "nonce":    nonce,
        "chainId":  1
    })

    signed = account.sign_transaction(txn)
    tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)
    return w3.to_hex(tx_hash)


# ─── Bot Startup ───────────────────────────────────────────────────────────────
async def main():
    print("[INFO] Starting MCPAIRIS_BOT. Polling for updates…")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
